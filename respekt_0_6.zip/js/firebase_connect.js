﻿  var config = {
    apiKey: "AIzaSyAUGf75YmzFtvxs8q2jIKqb4EC-cI9g2yI",
    authDomain: "respekt-1b30b.firebaseapp.com",
    databaseURL: "https://respekt-1b30b.firebaseio.com",
    storageBucket: "respekt-1b30b.appspot.com",
  };
  firebase.initializeApp(config);

  var db = firebase.database().ref();
